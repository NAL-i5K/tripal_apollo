create function get_feature_id(character varying, character varying, character varying)
  returns bigint
language sql
as $$
SELECT feature_id 
  FROM feature
  WHERE uniquename=$1
    AND type_id=get_feature_type_id($2)
    AND organism_id=get_organism_id($3)
$$;

alter function get_feature_id(varchar, varchar, varchar)
  owner to drupal;

