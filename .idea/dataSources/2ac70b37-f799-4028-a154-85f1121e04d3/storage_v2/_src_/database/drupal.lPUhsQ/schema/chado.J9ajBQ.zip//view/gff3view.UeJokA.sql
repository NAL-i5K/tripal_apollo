create view gff3view as
  SELECT f.feature_id,
         sf.name                                                   AS ref,
         COALESCE(gffdbx.accession, '.' :: character varying(255)) AS source,
         cv.name                                                   AS type,
         (fl.fmin + 1)                                             AS fstart,
         fl.fmax                                                   AS fend,
         COALESCE((af.significance) :: text, '.' :: text)          AS score,
         CASE
           WHEN (fl.strand = '-1' :: integer) THEN '-' :: text
           WHEN (fl.strand = 1) THEN '+' :: text
           ELSE '.' :: text
             END                                                   AS strand,
         COALESCE((fl.phase) :: text, '.' :: text)                 AS phase,
         f.seqlen,
         f.name,
         f.organism_id
  FROM (((((chado.feature f
      LEFT JOIN chado.featureloc fl ON ((f.feature_id = fl.feature_id)))
      LEFT JOIN chado.feature sf ON ((fl.srcfeature_id = sf.feature_id)))
      LEFT JOIN (SELECT fd.feature_id, d.accession
                 FROM ((chado.feature_dbxref fd
                     JOIN chado.dbxref d USING (dbxref_id))
                     JOIN chado.db USING (db_id))
                 WHERE ((db.name) :: text = 'GFF_source' :: text)) gffdbx ON ((f.feature_id = gffdbx.feature_id)))
      LEFT JOIN chado.cvterm cv ON ((f.type_id = cv.cvterm_id)))
      LEFT JOIN chado.analysisfeature af ON ((f.feature_id = af.feature_id)));

alter table gff3view
  owner to drupal;

