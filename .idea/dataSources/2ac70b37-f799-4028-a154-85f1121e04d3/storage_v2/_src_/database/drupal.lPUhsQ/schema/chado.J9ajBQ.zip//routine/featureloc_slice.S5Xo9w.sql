create function featureloc_slice(bigint, bigint, bigint)
  returns SETOF chado.featureloc
language sql
as $$
SELECT * 
   FROM featureloc 
   WHERE boxquery($1, $2, $3) && boxrange(srcfeature_id,fmin,fmax)
$$;

alter function featureloc_slice(bigint, bigint, bigint)
  owner to drupal;

