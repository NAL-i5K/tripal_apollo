create function boxrange(bigint, bigint, bigint)
  returns box
immutable
language sql
as $$
SELECT box (create_point($1, $2), create_point($1,$3))
$$;

alter function boxrange(bigint, bigint, bigint)
  owner to drupal;

