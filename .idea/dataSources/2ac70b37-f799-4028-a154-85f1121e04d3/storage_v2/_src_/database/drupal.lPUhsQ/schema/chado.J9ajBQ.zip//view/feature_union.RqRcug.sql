create view feature_union as
  SELECT x.feature_id AS subject_id,
         y.feature_id AS object_id,
         x.srcfeature_id,
         x.strand     AS subject_strand,
         y.strand     AS object_strand,
         CASE
           WHEN (x.fmin < y.fmin) THEN x.fmin
           ELSE y.fmin
             END      AS fmin,
         CASE
           WHEN (x.fmax > y.fmax) THEN x.fmax
           ELSE y.fmax
             END      AS fmax
  FROM chado.featureloc x,
       chado.featureloc y
  WHERE ((x.srcfeature_id = y.srcfeature_id) AND ((x.fmax >= y.fmin) AND (x.fmin <= y.fmax)));

comment on view feature_union
is 'set-union on interval defined by featureloc. featurelocs must meet';

alter table feature_union
  owner to drupal;

