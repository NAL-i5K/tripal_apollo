create function concat(text, anynonarray)
  returns text
language sql
as $$
SELECT $1 || CAST($2 AS text);
$$;

alter function concat(text, anynonarray)
  owner to drupal;

