create function concat(anynonarray, text)
  returns text
language sql
as $$
SELECT CAST($1 AS text) || $2;
$$;

alter function concat(anynonarray, text)
  owner to drupal;

