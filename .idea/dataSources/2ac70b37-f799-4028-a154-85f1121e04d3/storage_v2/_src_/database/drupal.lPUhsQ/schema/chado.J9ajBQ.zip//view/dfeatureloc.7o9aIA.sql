create view dfeatureloc as
  SELECT featureloc.featureloc_id,
         featureloc.feature_id,
         featureloc.srcfeature_id,
         featureloc.fmin            AS nbeg,
         featureloc.is_fmin_partial AS is_nbeg_partial,
         featureloc.fmax            AS nend,
         featureloc.is_fmax_partial AS is_nend_partial,
         featureloc.strand,
         featureloc.phase,
         featureloc.residue_info,
         featureloc.locgroup,
         featureloc.rank
  FROM chado.featureloc
  WHERE ((featureloc.strand < 0) OR (featureloc.phase < 0))
  UNION
  SELECT featureloc.featureloc_id,
         featureloc.feature_id,
         featureloc.srcfeature_id,
         featureloc.fmax            AS nbeg,
         featureloc.is_fmax_partial AS is_nbeg_partial,
         featureloc.fmin            AS nend,
         featureloc.is_fmin_partial AS is_nend_partial,
         featureloc.strand,
         featureloc.phase,
         featureloc.residue_info,
         featureloc.locgroup,
         featureloc.rank
  FROM chado.featureloc
  WHERE ((featureloc.strand IS NULL) OR (featureloc.strand >= 0) OR (featureloc.phase >= 0));

alter table dfeatureloc
  owner to drupal;

