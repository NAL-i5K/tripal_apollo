create view feature_difference as
  SELECT x.feature_id    AS subject_id,
         y.feature_id    AS object_id,
         x.strand        AS srcfeature_id,
         x.srcfeature_id AS fmin,
         x.fmin          AS fmax,
         y.fmin          AS strand
  FROM chado.featureloc x,
       chado.featureloc y
  WHERE ((x.srcfeature_id = y.srcfeature_id) AND ((x.fmin < y.fmin) AND (x.fmax >= y.fmax)))
  UNION
  SELECT x.feature_id    AS subject_id,
         y.feature_id    AS object_id,
         x.strand        AS srcfeature_id,
         x.srcfeature_id AS fmin,
         y.fmax,
         x.fmax          AS strand
  FROM chado.featureloc x,
       chado.featureloc y
  WHERE ((x.srcfeature_id = y.srcfeature_id) AND ((x.fmax > y.fmax) AND (x.fmin <= y.fmin)));

comment on view feature_difference
is 'size of gap between two features. must be abutting or disjoint';

alter table feature_difference
  owner to drupal;

