create view cv_path_count as
  SELECT cv.name AS cv_name, relation.name AS relation_name, relation_cv.name AS relation_cv_name, count(*) AS num_paths
  FROM ((((chado.cv
      JOIN chado.cvterm ON ((cvterm.cv_id = cv.cv_id)))
      JOIN chado.cvtermpath ON ((cvterm.cvterm_id = cvtermpath.subject_id)))
      JOIN chado.cvterm relation ON ((cvtermpath.type_id = relation.cvterm_id)))
      JOIN chado.cv relation_cv ON ((relation.cv_id = relation_cv.cv_id)))
  GROUP BY cv.name, relation.name, relation_cv.name;

comment on view cv_path_count
is 'per-cv summary of number of
paths (cvtermpaths) broken down by relationship_type. num_paths is the
total # of paths of the specified type in which the subject_id of the
path is in the named cv. See also: cv_distinct_relations';

alter table cv_path_count
  owner to drupal;

