create view cv_link_count as
  SELECT cv.name AS cv_name, relation.name AS relation_name, relation_cv.name AS relation_cv_name, count(*) AS num_links
  FROM ((((chado.cv
      JOIN chado.cvterm ON ((cvterm.cv_id = cv.cv_id)))
      JOIN chado.cvterm_relationship ON ((cvterm.cvterm_id = cvterm_relationship.subject_id)))
      JOIN chado.cvterm relation ON ((cvterm_relationship.type_id = relation.cvterm_id)))
      JOIN chado.cv relation_cv ON ((relation.cv_id = relation_cv.cv_id)))
  GROUP BY cv.name, relation.name, relation_cv.name;

comment on view cv_link_count
is 'per-cv summary of number of
links (cvterm_relationships) broken down by
relationship_type. num_links is the total # of links of the specified
type in which the subject_id of the link is in the named cv';

alter table cv_link_count
  owner to drupal;

