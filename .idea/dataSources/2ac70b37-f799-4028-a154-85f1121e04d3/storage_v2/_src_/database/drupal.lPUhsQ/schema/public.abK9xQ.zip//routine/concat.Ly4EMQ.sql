create function concat(text, text)
  returns text
language sql
as $$
SELECT $1 || $2;
$$;

alter function concat(text, text)
  owner to drupal;

