create function boxrange(bigint, bigint)
  returns box
immutable
language sql
as $$
SELECT box (create_point(0, $1), create_point($2,500000000))
$$;

alter function boxrange(bigint, bigint)
  owner to drupal;

