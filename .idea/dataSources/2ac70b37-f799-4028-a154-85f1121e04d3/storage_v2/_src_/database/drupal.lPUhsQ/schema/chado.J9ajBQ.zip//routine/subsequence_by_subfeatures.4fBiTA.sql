create function subsequence_by_subfeatures(bigint)
  returns text
language sql
as $$
SELECT subsequence_by_subfeatures($1,get_feature_relationship_type_id('part_of'),0,0)
$$;

alter function subsequence_by_subfeatures(bigint)
  owner to drupal;

