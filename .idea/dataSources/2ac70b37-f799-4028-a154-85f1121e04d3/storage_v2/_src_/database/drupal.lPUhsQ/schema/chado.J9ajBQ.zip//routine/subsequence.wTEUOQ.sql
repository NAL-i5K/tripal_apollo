create function subsequence(bigint, bigint, bigint, integer)
  returns text
language sql
as $$
SELECT 
  CASE WHEN $4<0 
   THEN reverse_complement(substring(srcf.residues,CAST(($2+1) as int),CAST(($3-$2) as int)))
   ELSE substring(residues,CAST(($2+1) as int),CAST(($3-$2) as int))
  END AS residues
  FROM feature AS srcf
  WHERE
   srcf.feature_id=$1
$$;

alter function subsequence(bigint, bigint, bigint, integer)
  owner to drupal;

