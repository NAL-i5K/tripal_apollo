create function first(anyelement, anyelement)
  returns anyelement
language sql
as $$
SELECT COALESCE($1, $2);
$$;

alter function first(anyelement, anyelement)
  owner to drupal;

