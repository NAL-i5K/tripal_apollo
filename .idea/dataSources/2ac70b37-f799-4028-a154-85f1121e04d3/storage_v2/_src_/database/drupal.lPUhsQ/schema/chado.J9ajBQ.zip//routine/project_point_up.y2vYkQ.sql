create function project_point_up(bigint, bigint, bigint, bigint)
  returns bigint
language sql
as $$
SELECT
  CASE WHEN $4<0
   THEN $3-$1             -- rev strand
   ELSE $1-$2             -- fwd strand
  END AS p
$$;

alter function project_point_up(bigint, bigint, bigint, bigint)
  owner to drupal;

