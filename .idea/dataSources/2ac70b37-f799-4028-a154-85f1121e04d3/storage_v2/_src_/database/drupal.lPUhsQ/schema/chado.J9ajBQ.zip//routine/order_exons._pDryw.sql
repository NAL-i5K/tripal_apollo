create function order_exons(bigint)
  returns void
language plpgsql
as $$
DECLARE
    parent_type      ALIAS FOR $1;
    exon_id          bigint;
    part_of          bigint;
    exon_type        bigint;
    strand           int;
    arow             RECORD;
    order_by         varchar;
    rowcount         int;
    exon_count       int;
    ordered_exons    int;    
    transcript_id    bigint;
    transcript_row   feature%ROWTYPE;
  BEGIN
    SELECT INTO part_of cvterm_id FROM cvterm WHERE name='part_of'
      AND cv_id IN (SELECT cv_id FROM cv WHERE name='relationship');
    --SELECT INTO exon_type cvterm_id FROM cvterm WHERE name='exon'
    --  AND cv_id IN (SELECT cv_id FROM cv WHERE name='sequence');
    --RAISE NOTICE 'part_of %, exon %',part_of,exon_type;
    FOR transcript_row IN
      SELECT * FROM feature WHERE type_id = parent_type
    LOOP
      transcript_id = transcript_row.feature_id;
      SELECT INTO rowcount count(*) FROM feature_relationship
        WHERE object_id = transcript_id
          AND rank = 0;
      --Dont modify this transcript if there are already numbered exons or
      --if there is only one exon
      IF rowcount = 1 THEN
        --RAISE NOTICE 'skipping transcript %, row count %',transcript_id,rowcount;
        CONTINUE;
      END IF;
      --need to reverse the order if the strand is negative
      SELECT INTO strand strand FROM featureloc WHERE feature_id=transcript_id;
      IF strand > 0 THEN
          order_by = 'fl.fmin';      
      ELSE
          order_by = 'fl.fmax desc';
      END IF;
      exon_count = 0;
      FOR arow IN EXECUTE 
        'SELECT fr.*, fl.fmin, fl.fmax
          FROM feature_relationship fr, featureloc fl
          WHERE fr.object_id  = '||transcript_id||'
            AND fr.subject_id = fl.feature_id
            AND fr.type_id    = '||part_of||'
            ORDER BY '||order_by
      LOOP
        --number the exons for a given transcript
        UPDATE feature_relationship
          SET rank = exon_count 
          WHERE feature_relationship_id = arow.feature_relationship_id;
        exon_count = exon_count + 1;
      END LOOP; 
    END LOOP;
  END;
$$;

alter function order_exons(bigint)
  owner to drupal;

