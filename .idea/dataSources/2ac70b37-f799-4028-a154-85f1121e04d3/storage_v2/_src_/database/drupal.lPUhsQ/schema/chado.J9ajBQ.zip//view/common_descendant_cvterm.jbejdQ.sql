create view common_descendant_cvterm as
  SELECT p1.object_id                        AS cvterm1_id,
         p2.object_id                        AS cvterm2_id,
         p1.subject_id                       AS ancestor_cvterm_id,
         p1.pathdistance                     AS pathdistance1,
         p2.pathdistance                     AS pathdistance2,
         (p1.pathdistance + p2.pathdistance) AS total_pathdistance
  FROM chado.cvtermpath p1,
       chado.cvtermpath p2
  WHERE (p1.subject_id = p2.subject_id);

comment on view common_descendant_cvterm
is 'The common descendant of
any two terms is the intersection of both terms descendants. Two terms
can have multiple common descendants. Use total_pathdistance to get
the least common ancestor';

alter table common_descendant_cvterm
  owner to drupal;

