create view featureset_meets as
  SELECT x.object_id AS subject_id, y.object_id
  FROM ((chado.feature_meets r
      JOIN chado.feature_relationship x ON ((r.subject_id = x.subject_id)))
      JOIN chado.feature_relationship y ON ((r.object_id = y.subject_id)));

alter table featureset_meets
  owner to drupal;

