create function get_cycle_cvterm_ids(bigint)
  returns SETOF bigint
language plpgsql
as $$
DECLARE
    cvid alias for $1;
    root cvterm%ROWTYPE;
    rtn     bigint;
BEGIN
    FOR root IN SELECT DISTINCT t.* from cvterm t WHERE cv_id = cvid LOOP
        SELECT INTO rtn get_cycle_cvterm_id(cvid,root.cvterm_id);
        IF (rtn > 0) THEN
            RETURN NEXT rtn;
        END IF;
    END LOOP;
    RETURN;
END;
$$;

alter function get_cycle_cvterm_ids(bigint)
  owner to drupal;

