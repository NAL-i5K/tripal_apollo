create function concat(anynonarray, anynonarray)
  returns text
language sql
as $$
SELECT CAST($1 AS text) || CAST($2 AS text);
$$;

alter function concat(anynonarray, anynonarray)
  owner to drupal;

