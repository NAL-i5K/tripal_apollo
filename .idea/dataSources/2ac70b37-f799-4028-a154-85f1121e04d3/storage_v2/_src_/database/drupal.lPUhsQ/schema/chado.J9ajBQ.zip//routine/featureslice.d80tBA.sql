create function featureslice(bigint, bigint)
  returns SETOF chado.featureloc
language sql
as $$
SELECT * from featureloc where boxquery($1, $2) @ boxrange(fmin,fmax)
$$;

alter function featureslice(bigint, bigint)
  owner to drupal;

