create function featureloc_slice(character varying, bigint, bigint)
  returns SETOF chado.featureloc
language sql
as $$
SELECT featureloc.* 
   FROM featureloc 
   INNER JOIN feature AS srcf ON (srcf.feature_id = featureloc.srcfeature_id)
   WHERE boxquery($2, $3) @ boxrange(fmin,fmax)
   AND srcf.name = $1
$$;

alter function featureloc_slice(varchar, bigint, bigint)
  owner to drupal;

