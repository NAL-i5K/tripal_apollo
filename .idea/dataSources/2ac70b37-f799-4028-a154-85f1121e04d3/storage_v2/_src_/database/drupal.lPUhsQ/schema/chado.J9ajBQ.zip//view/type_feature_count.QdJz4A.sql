create view type_feature_count as
  SELECT t.name AS type, count(*) AS num_features
  FROM (chado.cvterm t
      JOIN chado.feature ON ((feature.type_id = t.cvterm_id)))
  GROUP BY t.name;

comment on view type_feature_count
is 'per-feature-type feature counts';

alter table type_feature_count
  owner to drupal;

