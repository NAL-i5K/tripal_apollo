create function translate_codon(text, bigint)
  returns character
language sql
as $$
SELECT aa FROM genetic_code.gencode_codon_aa WHERE codon=$1 AND gencode_id=$2
$$;

alter function translate_codon(text, bigint)
  owner to drupal;

