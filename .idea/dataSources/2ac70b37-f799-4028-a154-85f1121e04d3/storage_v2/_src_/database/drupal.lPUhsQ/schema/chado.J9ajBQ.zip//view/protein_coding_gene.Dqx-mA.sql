create view protein_coding_gene as
  SELECT DISTINCT gene.feature_id,
                  gene.dbxref_id,
                  gene.organism_id,
                  gene.name,
                  gene.uniquename,
                  gene.residues,
                  gene.seqlen,
                  gene.md5checksum,
                  gene.type_id,
                  gene.is_analysis,
                  gene.is_obsolete,
                  gene.timeaccessioned,
                  gene.timelastmodified
  FROM ((chado.feature gene
      JOIN chado.feature_relationship fr ON ((gene.feature_id = fr.object_id)))
      JOIN so.mrna ON ((mrna.feature_id = fr.subject_id)));

alter table protein_coding_gene
  owner to drupal;

