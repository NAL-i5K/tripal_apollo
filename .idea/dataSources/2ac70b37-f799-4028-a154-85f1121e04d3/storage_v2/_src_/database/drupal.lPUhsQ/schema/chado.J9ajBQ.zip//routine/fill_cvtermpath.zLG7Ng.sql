create function fill_cvtermpath(character varying)
  returns integer
language plpgsql
as $$
DECLARE
    cvname alias for $1;
    cv_id   bigint;
    rtn     int;
BEGIN
    SELECT INTO cv_id cv.cv_id from cv WHERE cv.name = cvname;
    SELECT INTO rtn fill_cvtermpath(cv_id);
    RETURN rtn;
END;
$$;

alter function fill_cvtermpath(varchar)
  owner to drupal;

