create view cv_cvterm_count as
  SELECT cv.name, count(*) AS num_terms_excl_obs
  FROM (chado.cv
      JOIN chado.cvterm USING (cv_id))
  WHERE (cvterm.is_obsolete = 0)
  GROUP BY cv.name;

comment on view cv_cvterm_count
is 'per-cv terms counts (excludes obsoletes)';

alter table cv_cvterm_count
  owner to drupal;

