create view feature_meets as
  SELECT x.feature_id AS subject_id, y.feature_id AS object_id
  FROM chado.featureloc x,
       chado.featureloc y
  WHERE ((x.srcfeature_id = y.srcfeature_id) AND ((x.fmax >= y.fmin) AND (x.fmin <= y.fmax)));

comment on view feature_meets
is 'intervals have at least one
interbase point in common (ie overlap OR abut). symmetric,reflexive';

alter table feature_meets
  owner to drupal;

