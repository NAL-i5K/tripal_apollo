create view feature_intersection as
  SELECT x.feature_id AS subject_id,
         y.feature_id AS object_id,
         x.srcfeature_id,
         x.strand     AS subject_strand,
         y.strand     AS object_strand,
         CASE
           WHEN (x.fmin < y.fmin) THEN y.fmin
           ELSE x.fmin
             END      AS fmin,
         CASE
           WHEN (x.fmax > y.fmax) THEN y.fmax
           ELSE x.fmax
             END      AS fmax
  FROM chado.featureloc x,
       chado.featureloc y
  WHERE ((x.srcfeature_id = y.srcfeature_id) AND ((x.fmax >= y.fmin) AND (x.fmin <= y.fmax)));

comment on view feature_intersection
is 'set-intersection on interval defined by featureloc. featurelocs must meet';

alter table feature_intersection
  owner to drupal;

