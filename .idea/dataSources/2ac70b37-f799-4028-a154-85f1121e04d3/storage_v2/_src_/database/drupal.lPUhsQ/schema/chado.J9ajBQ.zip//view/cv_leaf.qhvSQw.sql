create view cv_leaf as
  SELECT cvterm.cv_id, cvterm.cvterm_id
  FROM chado.cvterm
  WHERE (NOT (cvterm.cvterm_id IN (SELECT cvterm_relationship.object_id FROM chado.cvterm_relationship)));

comment on view cv_leaf
is 'the leaves of a cv are the set of terms
which have no children (terms that are not the object of a
relation). All cvs will have at least 1 leaf';

alter table cv_leaf
  owner to drupal;

