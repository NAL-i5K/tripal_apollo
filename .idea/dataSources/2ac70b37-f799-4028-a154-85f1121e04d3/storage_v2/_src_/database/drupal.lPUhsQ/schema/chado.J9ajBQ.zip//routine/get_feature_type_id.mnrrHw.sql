create function get_feature_type_id(character varying)
  returns bigint
language sql
as $$
SELECT cvterm_id 
  FROM cv INNER JOIN cvterm USING (cv_id)
  WHERE cvterm.name=$1 AND cv.name='sequence'
$$;

alter function get_feature_type_id(varchar)
  owner to drupal;

