create view stats_paths_to_root as
  SELECT cvtermpath.subject_id                    AS cvterm_id,
         count(DISTINCT cvtermpath.cvtermpath_id) AS total_paths,
         avg(cvtermpath.pathdistance)             AS avg_distance,
         min(cvtermpath.pathdistance)             AS min_distance,
         max(cvtermpath.pathdistance)             AS max_distance
  FROM (chado.cvtermpath
      JOIN chado.cv_root ON ((cvtermpath.object_id = cv_root.root_cvterm_id)))
  GROUP BY cvtermpath.subject_id;

comment on view stats_paths_to_root
is 'per-cvterm statistics on its
placement in the DAG relative to the root. There may be multiple paths
from any term to the root. This gives the total number of paths, and
the average minimum and maximum distances. Here distance is defined by
cvtermpath.pathdistance';

alter table stats_paths_to_root
  owner to drupal;

