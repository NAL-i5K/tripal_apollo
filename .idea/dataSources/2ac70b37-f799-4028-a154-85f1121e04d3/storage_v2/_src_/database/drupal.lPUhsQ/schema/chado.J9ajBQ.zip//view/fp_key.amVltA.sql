create view fp_key as
  SELECT fp.feature_id, c.name AS pkey, fp.value
  FROM chado.featureprop fp,
       chado.cvterm c
  WHERE (fp.featureprop_id = c.cvterm_id);

alter table fp_key
  owner to drupal;

