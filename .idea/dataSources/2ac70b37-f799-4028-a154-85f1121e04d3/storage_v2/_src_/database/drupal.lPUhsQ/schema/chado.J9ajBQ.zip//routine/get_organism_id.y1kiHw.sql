create function get_organism_id(character varying)
  returns bigint
language sql
as $$
SELECT organism_id
  FROM organism
  WHERE genus=substring($1,1,position(' ' IN $1)-1)
    AND species=substring($1,position(' ' IN $1)+1)
$$;

alter function get_organism_id(varchar)
  owner to drupal;

