create function get_cv_id_for_feature_relationsgip()
  returns bigint
language sql
as $$
SELECT cv_id FROM cv WHERE name='relationship'
$$;

alter function get_cv_id_for_feature_relationsgip()
  owner to drupal;

