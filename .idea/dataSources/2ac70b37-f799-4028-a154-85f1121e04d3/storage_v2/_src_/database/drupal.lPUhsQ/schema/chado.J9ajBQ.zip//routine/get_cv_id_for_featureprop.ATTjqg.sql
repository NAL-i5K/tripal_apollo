create function get_cv_id_for_featureprop()
  returns bigint
language sql
as $$
SELECT cv_id FROM cv WHERE name='feature_property'
$$;

alter function get_cv_id_for_featureprop()
  owner to drupal;

