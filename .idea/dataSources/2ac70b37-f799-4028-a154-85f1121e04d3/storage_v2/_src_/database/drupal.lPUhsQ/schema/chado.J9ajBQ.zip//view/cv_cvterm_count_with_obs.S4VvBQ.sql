create view cv_cvterm_count_with_obs as
  SELECT cv.name, count(*) AS num_terms_incl_obs
  FROM (chado.cv
      JOIN chado.cvterm USING (cv_id))
  GROUP BY cv.name;

comment on view cv_cvterm_count_with_obs
is 'per-cv terms counts (includes obsoletes)';

alter table cv_cvterm_count_with_obs
  owner to drupal;

