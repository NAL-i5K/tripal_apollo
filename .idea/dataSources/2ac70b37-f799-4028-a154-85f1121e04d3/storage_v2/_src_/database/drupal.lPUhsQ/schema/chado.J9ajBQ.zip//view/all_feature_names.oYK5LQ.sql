create view all_feature_names as
  SELECT feature.feature_id,
         ("substring"(feature.uniquename, 0, 255)) :: character varying(255) AS name,
         feature.organism_id
  FROM chado.feature
  UNION
  SELECT feature.feature_id, feature.name, feature.organism_id
  FROM chado.feature
  WHERE (feature.name IS NOT NULL)
  UNION
  SELECT fs.feature_id, s.name, f.organism_id
  FROM chado.feature_synonym fs,
       chado.synonym s,
       chado.feature f
  WHERE ((fs.synonym_id = s.synonym_id) AND (fs.feature_id = f.feature_id))
  UNION
  SELECT fp.feature_id, ("substring"(fp.value, 0, 255)) :: character varying(255) AS name, f.organism_id
  FROM chado.featureprop fp,
       chado.feature f
  WHERE (f.feature_id = fp.feature_id)
  UNION
  SELECT fd.feature_id, d.accession AS name, f.organism_id
  FROM chado.feature_dbxref fd,
       chado.dbxref d,
       chado.feature f
  WHERE ((fd.dbxref_id = d.dbxref_id) AND (fd.feature_id = f.feature_id));

alter table all_feature_names
  owner to drupal;

