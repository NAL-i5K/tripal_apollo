create view db_dbxref_count as
  SELECT db.name, count(*) AS num_dbxrefs
  FROM (chado.db
      JOIN chado.dbxref USING (db_id))
  GROUP BY db.name;

comment on view db_dbxref_count
is 'per-db dbxref counts';

alter table db_dbxref_count
  owner to drupal;

