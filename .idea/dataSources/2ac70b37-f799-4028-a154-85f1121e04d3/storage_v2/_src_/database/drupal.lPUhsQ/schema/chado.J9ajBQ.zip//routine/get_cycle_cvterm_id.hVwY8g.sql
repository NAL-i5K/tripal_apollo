create function get_cycle_cvterm_id(character varying)
  returns bigint
language plpgsql
as $$
DECLARE
    cvname alias for $1;
    cv_id bigint;
    rtn bigint;
BEGIN
    SELECT INTO cv_id cv.cv_id from cv WHERE cv.name = cvname;
    SELECT INTO rtn  get_cycle_cvterm_id(cv_id);
    RETURN rtn;
END;
$$;

alter function get_cycle_cvterm_id(varchar)
  owner to drupal;

