create function boxquery(bigint, bigint)
  returns box
immutable
language sql
as $$
SELECT box (create_point($1, $2), create_point($1, $2))
$$;

alter function boxquery(bigint, bigint)
  owner to drupal;

