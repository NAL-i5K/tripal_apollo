create view f_type as
  SELECT f.feature_id,
         f.name,
         f.dbxref_id,
         c.name AS type,
         f.residues,
         f.seqlen,
         f.md5checksum,
         f.type_id,
         f.timeaccessioned,
         f.timelastmodified
  FROM chado.feature f,
       chado.cvterm c
  WHERE (f.type_id = c.cvterm_id);

alter table f_type
  owner to drupal;

