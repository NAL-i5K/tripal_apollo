create function concat_pair(text, text)
  returns text
language sql
as $$
SELECT $1 || $2
$$;

alter function concat_pair(text, text)
  owner to drupal;

