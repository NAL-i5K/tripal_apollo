create view cv_root as
  SELECT cvterm.cv_id, cvterm.cvterm_id AS root_cvterm_id
  FROM chado.cvterm
  WHERE ((NOT (cvterm.cvterm_id IN (SELECT cvterm_relationship.subject_id FROM chado.cvterm_relationship))) AND
         (cvterm.is_obsolete = 0));

comment on view cv_root
is 'the roots of a cv are the set of terms
which have no parents (terms that are not the subject of a
relation). Most cvs will have a single root, some may have >1. All
will have at least 1';

alter table cv_root
  owner to drupal;

