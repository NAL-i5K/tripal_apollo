create function get_feature_ids_by_propval(character varying)
  returns SETOF chado.feature_by_fx_type
language plpgsql
as $$
DECLARE
    p_val alias for $1;
    query TEXT;
    myrc feature_by_fx_type%ROWTYPE;
    myrc2 feature_by_fx_type%ROWTYPE;
BEGIN
    query := 'SELECT DISTINCT fprop.feature_id 
        FROM featureprop fprop WHERE fprop.value = ' || quote_literal(p_val) || ';';
    IF (STRPOS(p_val, '%') > 0) THEN
        query := 'SELECT DISTINCT fprop.feature_id 
            FROM featureprop fprop WHERE fprop.value::text like ' || quote_literal(p_val) || ';';
    END IF;
    FOR myrc IN SELECT * FROM get_feature_ids(query) LOOP
        RETURN NEXT myrc;
    END LOOP;
    RETURN;
END;
$$;

alter function get_feature_ids_by_propval(varchar)
  owner to drupal;

