create function store_db(character varying)
  returns bigint
language plpgsql
as $$
DECLARE
   v_name             ALIAS FOR $1;
   v_db_id            BIGINT;
 BEGIN
    SELECT INTO v_db_id db_id
      FROM db
      WHERE name=v_name;
    IF NOT FOUND THEN
      INSERT INTO db
       (name)
         VALUES
       (v_name);
       RETURN currval('db_db_id_seq');
    END IF;
    RETURN v_db_id;
 END;
$$;

alter function store_db(varchar)
  owner to drupal;

