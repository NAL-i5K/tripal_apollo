create function get_organism_id(character varying, character varying)
  returns bigint
language sql
as $$
SELECT organism_id 
  FROM organism
  WHERE genus=$1
    AND species=$2
$$;

alter function get_organism_id(varchar, varchar)
  owner to drupal;

