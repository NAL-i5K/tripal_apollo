create function subsequence_by_subfeatures(bigint, bigint)
  returns text
language sql
as $$
SELECT subsequence_by_subfeatures($1,$2,0,0)
$$;

alter function subsequence_by_subfeatures(bigint, bigint)
  owner to drupal;

