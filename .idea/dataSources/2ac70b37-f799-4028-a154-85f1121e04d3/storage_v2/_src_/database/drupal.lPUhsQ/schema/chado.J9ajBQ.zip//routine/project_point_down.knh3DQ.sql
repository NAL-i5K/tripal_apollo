create function project_point_down(bigint, bigint, bigint, bigint)
  returns bigint
language sql
as $$
SELECT
  CASE WHEN $4<0
   THEN $3-$1
   ELSE $1+$2
  END AS p
$$;

alter function project_point_down(bigint, bigint, bigint, bigint)
  owner to drupal;

