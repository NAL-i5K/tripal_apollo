create view f_loc as
  SELECT f.feature_id, f.name, f.dbxref_id, fl.nbeg, fl.nend, fl.strand
  FROM chado.dfeatureloc fl,
       chado.f_type f
  WHERE (f.feature_id = fl.feature_id);

alter table f_loc
  owner to drupal;

