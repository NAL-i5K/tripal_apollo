create view feature_disjoint as
  SELECT x.feature_id AS subject_id, y.feature_id AS object_id
  FROM chado.featureloc x,
       chado.featureloc y
  WHERE ((x.srcfeature_id = y.srcfeature_id) AND ((x.fmax < y.fmin) AND (x.fmin > y.fmax)));

comment on view feature_disjoint
is 'featurelocs do not meet. symmetric';

alter table feature_disjoint
  owner to drupal;

