create view gff3atts as
  SELECT fs.feature_id,
         'Ontology_term' :: text AS type,
         CASE
           WHEN ((db.name) :: text ~~ '%Gene Ontology%' :: text)
                   THEN (('GO:' :: text || (dbx.accession) :: text)) :: character varying
           WHEN ((db.name) :: text ~~ 'Sequence Ontology%' :: text)
                   THEN (('SO:' :: text || (dbx.accession) :: text)) :: character varying
           ELSE ((((db.name) :: text || ':' :: text) || (dbx.accession) :: text)) :: character varying
             END                 AS attribute
  FROM chado.cvterm s,
       chado.dbxref dbx,
       chado.feature_cvterm fs,
       chado.db
  WHERE ((fs.cvterm_id = s.cvterm_id) AND (s.dbxref_id = dbx.dbxref_id) AND (db.db_id = dbx.db_id))
  UNION ALL
  SELECT fs.feature_id,
         'Dbxref' :: text                                             AS type,
         (((d.name) :: text || ':' :: text) || (s.accession) :: text) AS attribute
  FROM chado.dbxref s,
       chado.feature_dbxref fs,
       chado.db d
  WHERE ((fs.dbxref_id = s.dbxref_id) AND (s.db_id = d.db_id) AND ((d.name) :: text <> 'GFF_source' :: text))
  UNION ALL
  SELECT f.feature_id, 'Alias' :: text AS type, s.name AS attribute
  FROM chado.synonym s,
       chado.feature_synonym fs,
       chado.feature f
  WHERE ((fs.synonym_id = s.synonym_id) AND (f.feature_id = fs.feature_id) AND
         ((f.name) :: text <> (s.name) :: text) AND (f.uniquename <> (s.name) :: text))
  UNION ALL
  SELECT fp.feature_id, cv.name AS type, fp.value AS attribute
  FROM chado.featureprop fp,
       chado.cvterm cv
  WHERE (fp.type_id = cv.cvterm_id)
  UNION ALL
  SELECT fs.feature_id, 'pub' :: text AS type, (((s.series_name) :: text || ':' :: text) || s.title) AS attribute
  FROM chado.pub s,
       chado.feature_pub fs
  WHERE (fs.pub_id = s.pub_id)
  UNION ALL
  SELECT fr.subject_id AS feature_id, 'Parent' :: text AS type, parent.uniquename AS attribute
  FROM chado.feature_relationship fr,
       chado.feature parent
  WHERE ((fr.object_id = parent.feature_id) AND (fr.type_id = (SELECT cvterm.cvterm_id
                                                               FROM chado.cvterm
                                                               WHERE (((cvterm.name) :: text = 'part_of' :: text) AND
                                                                      (cvterm.cv_id IN (SELECT cv.cv_id
                                                                                        FROM chado.cv
                                                                                        WHERE ((cv.name) :: text = 'relationship' :: text)))))))
  UNION ALL
  SELECT fr.subject_id AS feature_id, 'Derives_from' :: text AS type, parent.uniquename AS attribute
  FROM chado.feature_relationship fr,
       chado.feature parent
  WHERE ((fr.object_id = parent.feature_id) AND (fr.type_id = (SELECT cvterm.cvterm_id
                                                               FROM chado.cvterm
                                                               WHERE (((cvterm.name) :: text = 'derives_from' :: text) AND
                                                                      (cvterm.cv_id IN (SELECT cv.cv_id
                                                                                        FROM chado.cv
                                                                                        WHERE ((cv.name) :: text = 'relationship' :: text)))))))
  UNION ALL
  SELECT fl.feature_id,
         'Target' :: text AS type,
         (((((((target.name) :: text || ' ' :: text) || (fl.fmin + 1)) || ' ' :: text) || fl.fmax) || ' ' :: text) ||
          fl.strand)      AS attribute
  FROM chado.featureloc fl,
       chado.feature target
  WHERE ((fl.srcfeature_id = target.feature_id) AND (fl.rank <> 0))
  UNION ALL
  SELECT feature.feature_id, 'ID' :: text AS type, feature.uniquename AS attribute
  FROM chado.feature
  WHERE (NOT (feature.type_id IN
              (SELECT cvterm.cvterm_id FROM chado.cvterm WHERE ((cvterm.name) :: text = 'CDS' :: text))))
  UNION ALL
  SELECT feature.feature_id, 'chado_feature_id' :: text AS type, (feature.feature_id) :: character varying AS attribute
  FROM chado.feature
  UNION ALL
  SELECT feature.feature_id, 'Name' :: text AS type, feature.name AS attribute
  FROM chado.feature;

alter table gff3atts
  owner to drupal;

