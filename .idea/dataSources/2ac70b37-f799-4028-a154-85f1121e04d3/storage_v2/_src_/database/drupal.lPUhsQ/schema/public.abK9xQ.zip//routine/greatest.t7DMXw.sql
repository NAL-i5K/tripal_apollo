create function greatest(numeric, numeric, numeric)
  returns numeric
language sql
as $$
SELECT greatest($1, greatest($2, $3));
$$;

alter function greatest(numeric, numeric, numeric)
  owner to drupal;

