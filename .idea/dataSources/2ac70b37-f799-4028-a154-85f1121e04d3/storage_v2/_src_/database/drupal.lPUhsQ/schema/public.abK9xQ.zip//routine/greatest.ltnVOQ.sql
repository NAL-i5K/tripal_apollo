create function greatest(numeric, numeric)
  returns numeric
language sql
as $$
SELECT CASE WHEN (($1 > $2) OR ($2 IS NULL)) THEN $1 ELSE $2 END;
$$;

alter function greatest(numeric, numeric)
  owner to drupal;

