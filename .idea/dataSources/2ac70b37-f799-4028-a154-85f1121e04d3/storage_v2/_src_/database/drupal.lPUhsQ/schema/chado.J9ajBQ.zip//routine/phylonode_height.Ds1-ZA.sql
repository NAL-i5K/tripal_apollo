create function phylonode_height(bigint)
  returns double precision
language sql
as $$
SELECT coalesce(max(phylonode_height(phylonode_id) + distance), 0.0)
    FROM phylonode
    WHERE parent_phylonode_id = $1
$$;

alter function phylonode_height(bigint)
  owner to drupal;

