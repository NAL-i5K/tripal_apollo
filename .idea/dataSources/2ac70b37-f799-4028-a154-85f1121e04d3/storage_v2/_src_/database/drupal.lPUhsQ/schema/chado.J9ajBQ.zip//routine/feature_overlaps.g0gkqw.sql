create function feature_overlaps(bigint)
  returns SETOF chado.feature
language sql
as $$
SELECT feature.*
  FROM feature
   INNER JOIN featureloc AS x ON (x.feature_id=feature.feature_id)
   INNER JOIN featureloc AS y ON (y.feature_id = $1)
  WHERE
   x.srcfeature_id = y.srcfeature_id            AND
   ( x.fmax >= y.fmin AND x.fmin <= y.fmax )
$$;

alter function feature_overlaps(bigint)
  owner to drupal;

