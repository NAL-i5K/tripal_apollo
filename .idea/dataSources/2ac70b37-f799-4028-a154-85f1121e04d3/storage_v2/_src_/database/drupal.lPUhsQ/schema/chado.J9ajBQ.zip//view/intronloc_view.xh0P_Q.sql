create view intronloc_view as
  SELECT DISTINCT intron_combined_view.exon1_id,
                  intron_combined_view.exon2_id,
                  intron_combined_view.fmin,
                  intron_combined_view.fmax,
                  intron_combined_view.strand,
                  intron_combined_view.srcfeature_id
  FROM chado.intron_combined_view;

alter table intronloc_view
  owner to drupal;

