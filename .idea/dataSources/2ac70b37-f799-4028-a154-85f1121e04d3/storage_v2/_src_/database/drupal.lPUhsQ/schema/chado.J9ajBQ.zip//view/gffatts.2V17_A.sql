create view gffatts as
  SELECT fs.feature_id, 'Ontology_term' :: text AS type, s.name AS attribute
  FROM chado.cvterm s,
       chado.feature_cvterm fs
  WHERE (fs.cvterm_id = s.cvterm_id)
  UNION ALL
  SELECT fs.feature_id,
         'Dbxref' :: text                                             AS type,
         (((d.name) :: text || ':' :: text) || (s.accession) :: text) AS attribute
  FROM chado.dbxref s,
       chado.feature_dbxref fs,
       chado.db d
  WHERE ((fs.dbxref_id = s.dbxref_id) AND (s.db_id = d.db_id))
  UNION ALL
  SELECT fs.feature_id, 'Alias' :: text AS type, s.name AS attribute
  FROM chado.synonym s,
       chado.feature_synonym fs
  WHERE (fs.synonym_id = s.synonym_id)
  UNION ALL
  SELECT fp.feature_id, cv.name AS type, fp.value AS attribute
  FROM chado.featureprop fp,
       chado.cvterm cv
  WHERE (fp.type_id = cv.cvterm_id)
  UNION ALL
  SELECT fs.feature_id, 'pub' :: text AS type, (((s.series_name) :: text || ':' :: text) || s.title) AS attribute
  FROM chado.pub s,
       chado.feature_pub fs
  WHERE (fs.pub_id = s.pub_id);

alter table gffatts
  owner to drupal;

