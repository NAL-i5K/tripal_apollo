create function subsequence_by_feature(bigint)
  returns text
language sql
as $$
SELECT subsequence_by_feature($1,0,0)
$$;

alter function subsequence_by_feature(bigint)
  owner to drupal;

