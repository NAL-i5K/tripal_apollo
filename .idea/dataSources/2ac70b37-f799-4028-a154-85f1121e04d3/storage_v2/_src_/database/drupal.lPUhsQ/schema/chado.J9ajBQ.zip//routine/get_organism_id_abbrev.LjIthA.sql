create function get_organism_id_abbrev(character varying)
  returns bigint
language sql
as $$
SELECT organism_id
  FROM organism
  WHERE substr(genus,1,1)=substring($1,1,1)
    AND species=substring($1,position(' ' IN $1)+1)
$$;

alter function get_organism_id_abbrev(varchar)
  owner to drupal;

