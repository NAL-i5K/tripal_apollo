create function translate_dna(text)
  returns text
language sql
as $$
SELECT translate_dna($1,1)
$$;

alter function translate_dna(text)
  owner to drupal;

