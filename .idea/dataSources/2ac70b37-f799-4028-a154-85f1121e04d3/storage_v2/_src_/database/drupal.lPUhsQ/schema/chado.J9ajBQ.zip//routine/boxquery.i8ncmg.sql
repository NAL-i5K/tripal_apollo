create function boxquery(bigint, bigint, bigint)
  returns box
immutable
language sql
as $$
SELECT box (create_point($1, $2), create_point($1, $3))
$$;

alter function boxquery(bigint, bigint, bigint)
  owner to drupal;

