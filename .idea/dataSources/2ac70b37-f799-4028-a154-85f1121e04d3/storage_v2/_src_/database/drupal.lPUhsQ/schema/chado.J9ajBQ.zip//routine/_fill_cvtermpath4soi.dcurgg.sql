create function "_fill_cvtermpath4soi"(bigint, bigint)
  returns integer
language plpgsql
as $$
DECLARE
    rootid alias for $1;
    cvid alias for $2;
    ttype bigint;
    cterm soi_type%ROWTYPE;
BEGIN
    SELECT INTO ttype cvterm_id FROM cvterm WHERE name = 'isa';
    --RAISE NOTICE 'got ttype %',ttype;
    PERFORM _fill_cvtermpath4soinode(rootid, rootid, cvid, ttype, 0);
    FOR cterm IN SELECT tmp_type AS type_id, subject_id FROM tmpcvtr WHERE object_id = rootid LOOP
        PERFORM _fill_cvtermpath4soi(cterm.subject_id, cvid);
    END LOOP;
    RETURN 1;
END;
$$;

alter function "_fill_cvtermpath4soi"(bigint, bigint)
  owner to drupal;

