create function complement_residues(text)
  returns text
language sql
as $$
SELECT (translate($1, 
                   'acgtrymkswhbvdnxACGTRYMKSWHBVDNX',
                   'tgcayrkmswdvbhnxTGCAYRKMSWDVBHNX'))
$$;

alter function complement_residues(text)
  owner to drupal;

