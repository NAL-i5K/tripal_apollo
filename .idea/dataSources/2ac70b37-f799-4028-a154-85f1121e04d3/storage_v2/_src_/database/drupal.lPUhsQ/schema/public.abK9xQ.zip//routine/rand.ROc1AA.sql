create function rand()
  returns double precision
language sql
as $$
SELECT random();
$$;

alter function rand()
  owner to drupal;

