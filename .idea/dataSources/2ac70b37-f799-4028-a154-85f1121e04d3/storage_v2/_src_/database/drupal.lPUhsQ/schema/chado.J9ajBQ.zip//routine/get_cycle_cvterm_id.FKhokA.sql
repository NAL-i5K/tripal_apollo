create function get_cycle_cvterm_id(bigint, bigint)
  returns bigint
language plpgsql
as $$
DECLARE
    cvid alias for $1;
    rootid alias for $2;
    rtn     bigint;
BEGIN
    CREATE TEMP TABLE tmpcvtermpath(object_id bigint, subject_id bigint, cv_id bigint, type_id bigint, pathdistance int);
    CREATE INDEX tmp_cvtpath1 ON tmpcvtermpath(object_id, subject_id);
    SELECT INTO rtn _fill_cvtermpath4root2detect_cycle(rootid, cvid);
    IF (rtn > 0) THEN
        DROP TABLE tmpcvtermpath;
        RETURN rtn;
    END IF;
    DROP TABLE tmpcvtermpath;
    RETURN 0;
END;
$$;

alter function get_cycle_cvterm_id(bigint, bigint)
  owner to drupal;

