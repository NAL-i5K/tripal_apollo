create view feature_contains as
  SELECT x.feature_id AS subject_id, y.feature_id AS object_id
  FROM chado.featureloc x,
       chado.featureloc y
  WHERE ((x.srcfeature_id = y.srcfeature_id) AND ((y.fmin >= x.fmin) AND (y.fmin <= x.fmax)));

comment on view feature_contains
is 'subject intervals contains (or is
same as) object interval. transitive,reflexive';

alter table feature_contains
  owner to drupal;

