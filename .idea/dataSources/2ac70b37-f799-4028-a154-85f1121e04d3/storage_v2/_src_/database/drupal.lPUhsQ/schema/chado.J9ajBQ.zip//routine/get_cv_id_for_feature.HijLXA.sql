create function get_cv_id_for_feature()
  returns bigint
language sql
as $$
SELECT cv_id FROM cv WHERE name='sequence'
$$;

alter function get_cv_id_for_feature()
  owner to drupal;

