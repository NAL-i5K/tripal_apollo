create view feature_meets_on_same_strand as
  SELECT x.feature_id AS subject_id, y.feature_id AS object_id
  FROM chado.featureloc x,
       chado.featureloc y
  WHERE ((x.srcfeature_id = y.srcfeature_id) AND (x.strand = y.strand) AND ((x.fmax >= y.fmin) AND (x.fmin <= y.fmax)));

comment on view feature_meets_on_same_strand
is 'as feature_meets, but
featurelocs must be on the same strand. symmetric,reflexive';

alter table feature_meets_on_same_strand
  owner to drupal;

