create function reverse_complement(text)
  returns text
language sql
as $$
SELECT reverse_string(complement_residues($1))
$$;

alter function reverse_complement(text)
  owner to drupal;

