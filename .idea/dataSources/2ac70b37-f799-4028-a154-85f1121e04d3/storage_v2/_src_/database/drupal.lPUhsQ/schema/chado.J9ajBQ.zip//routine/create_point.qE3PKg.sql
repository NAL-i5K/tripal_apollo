create function create_point(bigint, bigint)
  returns point
language sql
as $$
SELECT point ($1, $2)
$$;

alter function create_point(bigint, bigint)
  owner to drupal;

